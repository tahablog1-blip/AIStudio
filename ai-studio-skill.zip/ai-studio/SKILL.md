---
name: ai-studio
description: AI Studio — a 31-role AI video production team that EXECUTES video work (editing, ads, YouTube/Shorts/TikTok/Reels, documentaries, tutorials, podcasts, music videos, motion graphics, intros/outros, 3D logos, colour correction & grading/LUTs, chroma key, tracking, background removal, stabilisation/upscale, voice-over, sound design, mixing, captions, thumbnails, platform export, QC). Use for ANY request to make, edit, fix, colour, caption, mix, animate or export a video, or when the user mentions "الاستوديو" / AI Studio / فريق المونتاج.
---

# AI Studio (استوديو الإنتاج)

The studio's code lives in the public repo **github.com/tahablog1-blip/AIStudio**. Every capability is a real command that produces files.

## 1. Make sure the studio is installed in this session (once)
```bash
S="${AISTUDIO_HOME:-$HOME/AIStudio}"
[ -d "$S/studio" ] || git clone -q --depth 1 https://github.com/tahablog1-blip/AIStudio.git "$S"
cd "$S" && git pull -q --ff-only || true
[ -f .bootstrapped ] || { bash bootstrap.sh && touch .bootstrapped; }     # add --with-3d only if a 3D task needs Blender
python3 -m studio roles | head -3
```
If the clone is refused by the network, read the environment docs for allowed hosts; github.com is normally reachable.

## 2. Work like the studio
1. Act as **executive-producer**: read `$S/CLAUDE.md`, `$S/README.md`, and `$S/docs/capabilities.md` (be honest about tools that are not available: Premiere/After Effects/Resolve/FCP/C4D/Nuke → deliver FCP7 XML/EDL instead).
2. Put the user's media in a project and plan it:
   ```bash
   cd "$S"
   python3 -m studio new "<name>" --brief "<goal>" --raw <files...>
   python3 -m studio plan <slug> promo --params '{"footage":[...],"script":"script.md","logo":"logo.png","brand":"...","tagline":"..."}'
   # or build a custom graph: python3 -m studio add-task <slug> <id> --role <role> --title "..." --fn <module.fn> --args '<json>' --deps ...
   python3 -m studio validate <slug> && python3 -m studio run <slug> --workers 4
   python3 -m studio status <slug>
   ```
3. Single specialist jobs: `python3 -m studio do <module.fn> --role <role> --args '<json>'` (roles may only use their authorised modules).
4. Each specialist's full brief (responsibilities, tools with argument examples, limits, hand-off protocol) is in `$S/.claude/agents/<role>.md`. For heavy parallel creative work, start sub-agents with the Agent tool and give each one its role file as instructions.
5. **Before delivering, look at sampled frames yourself** (extract with ffmpeg and view them) — automated QC passed in testing while caption order, colour on screen recordings and vertical cropping were visibly wrong. Fix → `python3 -m studio retry <slug> <task>` → re-run.
6. Deliverables are in `projects/<slug>/deliver/` (platform videos, thumbnails, Premiere/Resolve XML, QC report). Send them to the user.

## Roles (31)
executive-producer · creative-director · production-manager · film-director · cinematographer · screenwriter · storyboard-artist · lead-editor · cinema-editor · commercial-editor · documentary-editor · educational-editor · marketing-editor · social-editor · shortlong-editor · rhythmic-editor · vfx-artist · motion-designer · animator · compositor · motion-tracker · intro-outro · thumbnail-designer · colorist · color-grader · sound-engineer · sound-designer · voice-over · video-enhancement · encoding-engineer · quality-control

## Tool map (module → examples)
edit (render/auto_assemble/cut_silence/reframe/zoom_region/clip/finish/export_project) · rhythm (beats/beat_cut_timeline) · captions (transcribe/render_overlay/to_srt) · motion (render/title_card/lower_third/intro/outro) · three_d (text_3d) · color (correct/match/grade/make_lut) · vfx (key/composite/effect/letterbox) · tracking (track/attach/remove_bg) · audio (cleanup/mix/sfx_library/music_bed) · voice (tts/align) · enhance (stabilize/denoise/upscale/deinterlace/interpolate/restore) · thumbnail (best_frames/design/ab_set) · encode (export/export_many) · qc (check/check_many) · storyboard · script · analyze.
